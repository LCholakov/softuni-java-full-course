package fishing.entity.fisherman;


public interface Fisherman {

    String getName();

    int getHarvest();

    int getBait();

    void fishing();
}
