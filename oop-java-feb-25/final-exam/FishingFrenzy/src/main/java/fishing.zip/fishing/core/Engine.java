package fishing.core;

public interface Engine extends Runnable {
}
