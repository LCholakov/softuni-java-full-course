package fishing.common;

public enum Command {

    AddSite,
    AddFisherman,
    GoFishing,
    GetStatistics,
    Exit
}
